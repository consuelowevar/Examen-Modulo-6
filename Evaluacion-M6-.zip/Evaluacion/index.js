const fs = require('fs');
const express = require('express');
const app = express();

// Creamos una carpeta de recursos estaticos
app.use(express.static(__dirname + "/public"));


// Ruta Inicio pagina
app.get('/', (request, response) => 
{   
    response.render('index');
});

app.post('/roommates', (request, response) => {   
    //Funcion de moduloMaster, uso de Promesa.
    newRoommate()
        .then( (ranRoommate) => {
            saveRoommate(ranRoommate);
            response.end(JSON.stringify(ranRoommate));
        })
        .catch((err) => {
            response.statusCode = 500;
            response.end();
            console.log(err);
        });
});








/*   INICIO DE SERVIDOR  */
var server = app.listen(8080, () => {
    console.log(`Servidor web iniciado en puerto ${8080}`);
});