let addRoommate = document.querySelector('#addRoommate');

addRoommate.addEventListener("click", async () => { 
    await axios.post('/roommates', {responseType: 'json'})
            .then((response) => {
                    if(response.status==200){
                            
                            renderStatus(`El código de estado de respuesta HTTP es: ${response.status}`);  
                    }
            })
            .catch((err) => {
                    console.log(err);
            }); 
});